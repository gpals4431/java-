/* gulpfile.js */
var gulp = require('gulp');

/* Include Plugins
-------------------------------------------------- */
var plugins = require('gulp-load-plugins')({
    pattern: ['gulp-*', 'gulp.*', 'main-bower-files'],
    replaceString: /\bgulp[\-.]/
});

/* Task: Bower Copy
-------------------------------------------------- */
gulp.task('bower:copy', async function () {

    /* copy bower css files to css folder */
    gulp.src(plugins.mainBowerFiles('**/*.css'))
        .pipe(plugins.rename(function (path) {
            /* rename smartmenus */
            if ('jquery.smartmenus.bootstrap-4' === path.basename) path.basename = 'smartmenus-bootstrap';

            /* remove jquery prefix */
            path.basename = path.basename.replace('jquery.', '');

            /* lowercase */
            path.basename = path.basename.toLowerCase();
        }))
        .pipe(gulp.dest('css/'))

        /* minify */
        .pipe(plugins.minifier({
            minify: true,
            minifyCSS: true
        }))
        .pipe(plugins.rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest('css/'));

    /* copy bower js files to js folder */
    gulp.src(plugins.mainBowerFiles('**/*.js'))
        .pipe(plugins.rename(function (path) {
            /* rename smartmenus */
            if ('jquery.smartmenus' === path.basename) path.basename = 'smartmenus';
            if ('jquery.smartmenus.bootstrap-4' === path.basename) path.basename = 'smartmenus-bootstrap';

            /* rename magnific popup */
            if ('jquery.magnific-popup' === path.basename) path.basename = 'magnific-popup';

            /* remove jquery prefix */
            path.basename = path.basename.replace('jquery.', '');

            /* lowercase */
            path.basename = path.basename.toLowerCase();
        }))
        .pipe(gulp.dest('js/'))

        /* minify */
        .pipe(plugins.minifier({
            minify: true,
            minifyJS: true
        }))
        .pipe(plugins.rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest('js/'));

    /* copy webfonts to fonts folder */
    gulp.src(plugins.mainBowerFiles('**/webfonts/*'))
        .pipe(gulp.dest('fonts/'));
});

/* Task: Font Awesome SCSS
-------------------------------------------------- */
gulp.task('scss:font-awesome', function () {
    return gulp.src('scss/font-awesome.scss')
        .pipe(plugins.sass({
            outputStyle: 'expanded',
            precison: 3,
            errLogToConsole: true
        }))
        .pipe(gulp.dest('css/'))

        /* minify */
        .pipe(plugins.minifier({
            minify: true,
            minifyCSS: true
        }))
        .pipe(plugins.rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest('css/'));
});

/* Task: Bootstrap SCSS
-------------------------------------------------- */
gulp.task('scss:bootstrap', function () {
    return gulp.src('scss/bootstrap.scss')
        .pipe(plugins.sass({
            outputStyle: 'expanded',
            precison: 3,
            errLogToConsole: true
        }))
        .pipe(gulp.dest('css/'))

        /* minify */
        .pipe(plugins.minifier({
            minify: true,
            minifyCSS: true
        }))
        .pipe(plugins.rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest('css/'));
});

/* Task: Swiper SCSS
-------------------------------------------------- */
gulp.task('scss:swiper', function () {
    return gulp.src('scss/swiper.scss')
        .pipe(plugins.sass({
            outputStyle: 'expanded',
            precison: 3,
            errLogToConsole: true
        }))
        .pipe(gulp.dest('css/'))

        /* minify */
        .pipe(plugins.minifier({
            minify: true,
            minifyCSS: true
        }))
        .pipe(plugins.rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest('css/'));
});

/* Task: Lana Pet Theme SCSS
-------------------------------------------------- */
gulp.task('scss:lana-pet-theme', function () {
    return gulp.src('scss/lana-pet-theme.scss')
        .pipe(plugins.sass({
            outputStyle: 'expanded',
            precison: 3,
            errLogToConsole: true
        }))
        .pipe(gulp.dest('css/'))

        /* minify */
        .pipe(plugins.minifier({
            minify: true,
            minifyCSS: true
        }))
        .pipe(plugins.rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest('css/'));
});

/* Task: Lana Pet Icon SCSS
-------------------------------------------------- */
gulp.task('scss:lana-pet-icon', function () {
    return gulp.src('scss/lana-pet-icon.scss')
        .pipe(plugins.sass({
            outputStyle: 'expanded',
            precison: 3,
            errLogToConsole: true
        }))
        .pipe(gulp.dest('css/'))

        /* minify */
        .pipe(plugins.minifier({
            minify: true,
            minifyCSS: true
        }))
        .pipe(plugins.rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest('css/'));
});

/* Task: Lana Pet Print SCSS
-------------------------------------------------- */
gulp.task('scss:lana-pet-print', function () {
    return gulp.src('scss/lana-pet-print.scss')
        .pipe(plugins.sass({
            outputStyle: 'expanded',
            precison: 3,
            errLogToConsole: true
        }))
        .pipe(gulp.dest('css/'))

        /* minify */
        .pipe(plugins.minifier({
            minify: true,
            minifyCSS: true
        }))
        .pipe(plugins.rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest('css/'));
});

/* Task: Watch Task
-------------------------------------------------- */
gulp.task('watch', function () {

    /* watch bootstrap */
    gulp.watch([
        'scss/bootstrap/*.scss',
        'scss/bootstrap.scss'
    ], gulp.series('scss:bootstrap'));

    /* watch swiper */
    gulp.watch([
        'scss/swiper/*.scss',
        'scss/swiper.scss',
        'scss/bootstrap/_variables.scss'
    ], gulp.series('scss:swiper'));

    /* watch lana pet theme */
    gulp.watch([
        'scss/lana-pet-theme.scss',
        'scss/_animation.scss',
        'scss/effects/*.scss',
        'scss/mixins/*.scss',
        'scss/theme-elements/*.scss',
        'scss/theme-templates/*.scss',
        'scss/bootstrap/_variables.scss'
    ], gulp.series('scss:lana-pet-theme'));

    /* watch lana pet icon */
    gulp.watch([
        'scss/lana-pet-icon.scss'
    ], gulp.series('scss:lana-pet-icon'));

    /* watch lana pet print */
    gulp.watch([
        'scss/lana-pet-print.scss'
    ], gulp.series('scss:lana-pet-print'));
});

/* Task: Default Task
-------------------------------------------------- */
gulp.task('default', gulp.series('bower:copy', 'scss:font-awesome', 'scss:bootstrap', 'scss:swiper', 'scss:lana-pet-theme', 'scss:lana-pet-icon', 'scss:lana-pet-print', 'watch'));